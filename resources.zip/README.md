<img align="right" width="150" height="150" src="https://raw.githubusercontent.com/yltx/vscode-luogu/master/logo.png">

# vscode-luogu

轻松的让你在 VSCode 上使用洛谷。

## 使用说明

请参考 `Github` 上的 [wiki](https://www.github.com/yltx/vscode-luogu/wiki) 页面。

所有常用功能均有快捷键。

## 完成功能

- 查看题目
- 登录账号
- 注销账号
- 提交代码
- 查看自己测评
- 打卡
- 题目离线查看
- 查看最近一次评测
- 查看、发布犇犇
- 查看题解
- 给题解点赞/踩
- 比赛相关功能
- 根据题目难度及来源随机跳题
  
## 开发中功能
  
- 查看、发布讨论
  
## Others

Luogu图标来自[Luogu](https://www.luogu.com.cn/)，严禁商业使用

UI图标来自：[链接到Icons8](https://icons8.cn/)

用户交流群：1141066631

## LICENSE

Follow [MIT](LICENSE) LICENSE.

## 开发者

- Himself65
- 引领天下
- YanWQmonad
- FangZeLi
- andyli
- 蒟蒻水儿
- [宝硕](https://baoshuo.ren)
